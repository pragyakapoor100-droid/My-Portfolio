# Pragya Kapoor — SEO & Digital Marketing Portfolio

Live portfolio site for Pragya Kapoor, SEO & Digital Marketing Specialist based in Manchester, UK.

🌐 **Live site:** https://pragyakapoor.github.io

---

## About

Full-stack SEO and digital marketing specialist with 3+ years of experience across e-commerce, SaaS, health, and heavy industry. Covering technical SEO, content strategy, on-page optimisation, off-page authority building, digital PR, and Shopify e-commerce SEO.

**Open to:** Full-time and freelance SEO roles — Manchester and remote.

📧 pragyakapoor100@gmail.com  
🔗 [linkedin.com/in/pragyakapoor100](https://linkedin.com/in/pragyakapoor100)

---

## Tech

Single-file HTML portfolio — no build step, no dependencies.  
Hosted via [GitHub Pages](https://pages.github.com/).
